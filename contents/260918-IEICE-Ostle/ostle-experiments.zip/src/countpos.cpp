// Counts the number of **positions** in the sense of the paper. It does not solve.
//
// In the Preliminaries a position is (current configuration, player to move,
// previous configuration). These correspond one to one with the edges of the game
// tree: one edge = one (previous configuration, current configuration) pair.
// Edges cannot be given a combinatorial ranking, so holding them explicitly would
// need a hash table; for 5x5 with capture threshold two that is 68 billion entries
// at over 20 bytes each, more than 1 TB, which does not fit in 256 GB.
//
// But **counting them needs no such table**. The outcome is already determined by
// the (configuration, player to move, forbidden move) encoding, since two
// positions that differ only in the previous configuration have exactly the same
// continuations. So the reachable states can be swept while the edges are counted
// one at a time and discarded, at constant memory.
//
// Only representatives modulo reflection are stored, so each representative is
// weighted by the size of its orbit to recover the true, unreflected count.
//
// If LOAD_VALUES points at a file saved by solveq, the positions are classified by
// the outcome of the position they lead to.
//
// Build: g++ -O2 -std=c++17 -o build/countpos src/countpos.cpp
// Run  : LOAD_VALUES=v.bin ./build/countpos <height> <width> <q>
//
// This is solve5x5ref.cpp (capture threshold one) generalised to threshold q.
// Only three things changed; the state handling, the normalisation and the
// retrograde analysis are untouched.
//
//   (1) applyMove: the position is kept, with the side to move swapped, even when
//       a marker is removed
//   (2) the outcome test is "fewer than PMIN markers" instead of "one removed"
//   (3) arguments: the third is now q and the fourth the state-count limit
//
// With q=1, PMIN = p and the behaviour is identical to the original solve5x5ref.
//
// ## Why a second implementation exists
//
// solveidx.cpp indexed the whole state space and found 5x5 to be a draw. But it
// carries its own numbering (rankgen.h) and its own applyMove. A checker built to
// the same design, verify5x5.cpp, would share both and so would not be an
// independent check.
//
// This file is instead built on solver6.cpp from the parent repository.
//
//   * state handling : hash table (no combinatorial ranking)
//   * scope          : **reachable states only**, not the whole space
//   * normalisation  : unified side to move, reflections, and collapsing of
//                      forbidden moves that can no longer be played
//   * retrograde     : the classical method, with an explicit list of predecessors
//
// Neither the way states are held nor the direction of the search matches
// solveidx, so a bug in one does not propagate to the other.
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "rankgenq.h"

static int N = 4, M = 2, NCELL = 8;
static int Q = 1, PMIN = 2;   // PMIN = markers - Q + 1; below this the player has lost

static const int DR[4] = { -1, 1, 0, 0 };
static const int DC[4] = { 0, 0, -1, 1 };
// how a reflection maps the directions
static const int FLIP_V[4] = { 1, 0, 2, 3 };   // vertical flip: U<->D
static const int FLIP_H[4] = { 0, 1, 3, 2 };   // horizontal flip: L<->R

static inline bool inBoard(int r, int c) { return r >= 0 && r < N && c >= 0 && c < M; }

static const uint8_t NO_MOVE = 0xFF;

// ---------------------------------------------------------------------------
// State
//   cur : markers of the player to move
//   opp : markers of the opponent
//   ban : the forbidden move (source*4 + direction); NO_MOVE if none.
//         It records that playing this move would restore the previous board.
// ---------------------------------------------------------------------------
struct State {
    uint64_t cur, opp;
    uint8_t  ban;
    bool operator==(const State& o) const {
        return cur == o.cur && opp == o.opp && ban == o.ban;
    }
};

// lexicographic comparison, used to pick the representative
static inline bool stateLess(const State& a, const State& b) {
    if (a.cur != b.cur) return a.cur < b.cur;
    if (a.opp != b.opp) return a.opp < b.opp;
    return a.ban < b.ban;
}

// ---------------------------------------------------------------------------
// reflections
// ---------------------------------------------------------------------------
static inline uint64_t flipMask(uint64_t mask, bool h, bool v) {
    if (!h && !v) return mask;
    uint64_t out = 0;
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < M; c++) {
            if (!((mask >> (r * M + c)) & 1ULL)) continue;
            const int nr = v ? N - 1 - r : r;
            const int nc = h ? M - 1 - c : c;
            out |= 1ULL << (nr * M + nc);
        }
    }
    return out;
}

static inline uint8_t flipMove(uint8_t mv, bool h, bool v) {
    if (mv == NO_MOVE) return NO_MOVE;
    int src = mv >> 2, d = mv & 3;
    int r = src / M, c = src % M;
    if (h) { c = M - 1 - c; d = FLIP_H[d]; }
    if (v) { r = N - 1 - r; d = FLIP_V[d]; }
    return (uint8_t)(((r * M + c) << 2) | d);
}

// the lexicographically smallest of the four reflections is the representative
static inline State canonical(State s) {
    State best = s;
    for (int t = 1; t < 4; t++) {
        const bool h = t & 1, v = t & 2;
        State x{ flipMask(s.cur, h, v), flipMask(s.opp, h, v), flipMove(s.ban, h, v) };
        if (stateLess(x, best)) best = x;
    }
    return best;
}

// ---------------------------------------------------------------------------
// Collapses a forbidden move that can no longer be played.
//   If the square the forbidden move starts from holds no marker of the player
//   to move, that move could not be played anyway. Normalising it to NONE merges
//   states that differ only in history.
//   This is the reduction that pays off most in the collaborator's implementation.
// ---------------------------------------------------------------------------
static inline void normalizeBan(State& s) {
    if (s.ban == NO_MOVE) return;
    const int src = s.ban >> 2;
    if (!((s.cur >> src) & 1ULL)) s.ban = NO_MOVE;
}

// ---------------------------------------------------------------------------
// Applies a move, from the point of view of the player to move.
//   Returns true if the move is legal.
//   nextState is the state after swapping the side to move (cur/opp exchanged).
//   dropCur/dropOpp are the numbers of markers removed.
// ---------------------------------------------------------------------------
static inline bool applyMove(const State& s, int from, int d,
                             State& next, int& winner) {
    // winner: 0 = game continues, 1 = the player to move wins, 2 = they lose
    if (!((s.cur >> from) & 1ULL)) return false;
    if (s.ban != NO_MOVE && s.ban == (uint8_t)((from << 2) | d)) return false;

    const uint64_t occ = s.cur | s.opp;
    const int dr = DR[d], dc = DC[d];

    // Build the line to be pushed, starting with the marker being moved.
    int line[64], len = 1;
    line[0] = from;
    int rr = from / M + dr, cc = from % M + dc;
    int dest = inBoard(rr, cc) ? rr * M + cc : -1;
    while (dest >= 0 && ((occ >> dest) & 1ULL)) {
        line[len++] = dest;
        rr = dest / M + dr; cc = dest % M + dc;
        dest = inBoard(rr, cc) ? rr * M + cc : -1;
    }

    // Advance the line one square at a time, from its far end.
    // If a marker leaves the board the game is decided; when several would fall,
    // the colour of the nearer one decides the outcome.
    uint64_t ncur = s.cur, nopp = s.opp;
    winner = 0;
    int hole = dest;                   // the empty square beyond the line (-1 means off the board)
    for (int i = len - 1; i >= 0; i--) {
        const uint64_t bit = 1ULL << line[i];
        if (ncur & bit) {
            ncur ^= bit;
            if (hole < 0) winner = 2;  // own marker removed -> the player to move loses
            else ncur |= 1ULL << hole;
        } else {
            nopp ^= bit;
            if (hole < 0) winner = 1;  // opponent marker removed -> the player to move wins
            else nopp |= 1ULL << hole;
        }
        hole = line[i];
    }

    // With capture threshold q the game continues after a marker is removed, so
    // the position must not be discarded as it is for threshold one. A marker
    // pushed off the board cannot be restored in one move, so no forbidden move
    // is recorded.
    if (winner != 0) {
        next = State{ nopp, ncur, NO_MOVE };   // swap the side to move
        return true;
    }

    // The forbidden move as seen by the next player to move.
    // dest is the empty square at the head of the pushed line; moving the marker
    // that came to rest there back again is the move that restores the previous
    // board.
    //
    // Only the owner of that marker can play the reverse move, so the
    // restriction matters only when the marker on dest belongs to the next
    // player to move (nopp). Otherwise it would lapse on the next move, so it is
    // collapsed to NO_MOVE, merging states that differ only in history.
    // (This is the largest reduction in the collaborator's implementation.)
    uint8_t back = NO_MOVE;
    if (dest >= 0 && ((nopp >> dest) & 1ULL)) {
        back = (uint8_t)((dest << 2) | (d ^ 1));   // d^1 swaps U<->D and L<->R
    }

    next = State{ nopp, ncur, back };   // exchange the side to move
    return true;
}

// ---------------------------------------------------------------------------
// Hash table (open addressing)
// ---------------------------------------------------------------------------
static inline uint64_t mix64(uint64_t z) {
    z += 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

struct Table {
    std::vector<State>    keys;
    std::vector<uint32_t> vals;    // 0 = empty, otherwise id+1
    uint64_t mask;

    uint64_t count = 0;
    void init(uint64_t cap) {
        uint64_t n = 1;
        while (n < cap * 2) n <<= 1;
        keys.assign(n, State{0, 0, 0});
        vals.assign(n, 0);
        mask = n - 1;
        count = 0;
    }
    // Double the table once the load factor passes 0.5.
    // The original solver6 does not do this; past capacity its linear probing
    // degenerates and it burns CPU without making progress. Essential for 5x5.
    void grow() {
        std::vector<State> ok = std::move(keys);
        std::vector<uint32_t> ov = std::move(vals);
        const uint64_t n = (ok.size() ? ok.size() : 1) << 1;
        keys.assign(n, State{0, 0, 0});
        vals.assign(n, 0);
        mask = n - 1;
        for (size_t i = 0; i < ok.size(); i++) {
            if (!ov[i]) continue;
            uint64_t h = mix64(ok[i].cur ^ mix64(ok[i].opp) ^ ((uint64_t)ok[i].ban << 56)) & mask;
            while (vals[h]) h = (h + 1) & mask;
            keys[h] = ok[i]; vals[h] = ov[i];
        }
    }
    // Returns the id if present; otherwise inserts and assigns newId.
    uint32_t findOrInsert(const State& s, uint32_t newId, bool& isNew) {
        if ((count + 1) * 2 > keys.size()) grow();
        uint64_t h = mix64(s.cur ^ mix64(s.opp) ^ ((uint64_t)s.ban << 56)) & mask;
        while (true) {
            if (vals[h] == 0) {
                keys[h] = s; vals[h] = newId + 1; isNew = true; count++;
                return newId;
            }
            if (keys[h] == s) { isNew = false; return vals[h] - 1; }
            h = (h + 1) & mask;
        }
    }
    bool find(const State& s, uint32_t& id) const {
        uint64_t h = mix64(s.cur ^ mix64(s.opp) ^ ((uint64_t)s.ban << 56)) & mask;
        while (true) {
            if (vals[h] == 0) return false;
            if (keys[h] == s) { id = vals[h] - 1; return true; }
            h = (h + 1) & mask;
        }
    }
};

int main(int argc, char** argv) {
    if (argc >= 3) { N = std::atoi(argv[1]); M = std::atoi(argv[2]); }
    Q = (argc >= 4) ? std::atoi(argv[3]) : 1;
    PMIN = M - Q + 1;
    if (PMIN < 1) { std::fprintf(stderr, "q exceeds the number of markers\n"); return 1; }
    // The number of reachable states is not known in advance, so stop safely once
    // the limit is passed. This keeps the process from exhausting memory and
    // taking the machine down with it.
    uint64_t stateLimit = (argc >= 5) ? std::strtoull(argv[4], nullptr, 10) : 0;
    NCELL = N * M;
    if (N < 2) { std::fprintf(stderr, "n must be at least 2\n"); return 1; }
    if (NCELL > 63) { std::fprintf(stderr, "n*m must be at most 63\n"); return 1; }
    if (NCELL * 4 > 255) { std::fprintf(stderr, "n*m*4 exceeds 255\n"); return 1; }

    const auto t0 = std::chrono::steady_clock::now();

    // initial position (the first player occupies the bottom row)
    State init{ 0, 0, NO_MOVE };
    for (int c = 0; c < M; c++) {
        init.cur |= 1ULL << ((N - 1) * M + c);   // the player to move is the first player
        init.opp |= 1ULL << c;
    }
    init = canonical(init);

    Table table;
    table.init(1 << 20);

    // Nothing is solved here, so neither values nor predecessors are kept; only the
    // list of representatives.
    std::vector<State> states;

    auto getId = [&](const State& s, bool& isNew) -> uint32_t {
        const uint32_t id = (uint32_t)states.size();
        const uint32_t got = table.findOrInsert(s, id, isNew);
        if (isNew) states.push_back(s);
        return got;
    };

    bool dummy;
    const uint32_t initId = getId(init, dummy);

    uint64_t edgeCount = 0;

    // -----------------------------------------------------------------------
    // Enumerate the reachable representatives. Nothing is solved; the edges are
    // only counted.
    // -----------------------------------------------------------------------
    bool aborted = false;
    for (size_t qi = 0; qi < states.size(); qi++) {
        if (stateLimit && states.size() >= stateLimit) { aborted = true; break; }
        if ((qi & 0xFFFFFF) == 0 && qi) {
            std::printf("  enumerating: expanded %zu / known %zu\n", qi, states.size());
            std::fflush(stdout);
        }
        const State s = states[qi];
        uint64_t t = s.cur;
        while (t) {
            const int from = __builtin_ctzll(t);
            t &= t - 1;
            for (int d = 0; d < 4; d++) {
                State nx;
                int winner;
                if (!applyMove(s, from, d, nx, winner)) continue;
                if (__builtin_popcountll(nx.cur) < PMIN) continue;   // playing it wins at once: terminal
                if (__builtin_popcountll(nx.opp) < PMIN) continue;   // playing it loses at once: terminal
                bool isNew;
                getId(canonical(nx), isNew);
            }
        }
    }
    if (aborted) {
        std::printf("enumeration stopped at the limit of %llu. ABORTED\n", (unsigned long long)stateLimit);
        return 2;
    }
    const auto t1 = std::chrono::steady_clock::now();

    // -----------------------------------------------------------------------
    // Counting.
    //   For each representative s take the size o(s) of its orbit, then
    //     reachable states += o(s)
    //     positions (= edges) += o(s) x (number of moves to a non-terminal state)
    //   and classify by the outcome of the position reached. Outcomes are
    //   invariant under reflection, so the representative's value may be used.
    // -----------------------------------------------------------------------
    rankgenq::init(N, M, M, Q);
    const uint64_t TOTAL = rankgenq::TOTAL_CNT;
    std::vector<uint8_t> value;
    bool haveV = false;
    if (const char* vf = std::getenv("LOAD_VALUES")) {
        value.assign(TOTAL, 0);
        FILE* fp = std::fopen(vf, "rb");
        if (!fp) { std::fprintf(stderr, "cannot open %s\n", vf); return 1; }
        const size_t got = std::fread(value.data(), 1, value.size(), fp);
        std::fclose(fp);
        if (got != value.size()) { std::fprintf(stderr, "size mismatch %zu != %zu\n", got, value.size()); return 1; }
        haveV = true;
    }
    auto getV = [&](uint64_t i) -> uint8_t { return haveV ? value[i] : 0; };

    uint64_t nState = 0, nPos = 0, moveCount = 0, dupCfg = 0;
    uint64_t sW = 0, sL = 0, sD = 0;      // reachable states classified by outcome
    uint64_t pW = 0, pL = 0, pD = 0;      // positions classified by the outcome they lead to
    for (size_t i = 0; i < states.size(); i++) {
        const State s = states[i];
        // size of the orbit
        State orb[4]; int no = 0;
        for (int k = 0; k < 4; k++) {
            const bool h = k & 1, v = k & 2;
            State x{ flipMask(s.cur, h, v), flipMask(s.opp, h, v), flipMove(s.ban, h, v) };
            bool dup = false;
            for (int j = 0; j < no; j++) if (orb[j] == x) { dup = true; break; }
            if (!dup) orb[no++] = x;
        }
        const uint64_t o = (uint64_t)no;
        nState += o;
        const uint8_t vs = getV(rankgenq::stateIndex(s.cur, s.opp, s.ban));
        if (vs == 1) sW += o; else if (vs == 2) sL += o; else sD += o;

        // A position is (previous configuration, current configuration, player to
        // move), so moves reaching the same configuration count once. Whether the
        // number of moves differs from the number of configurations is measured too.
        State ch[80]; int nch = 0, moves = 0;
        uint64_t t2 = s.cur;
        while (t2) {
            const int from = __builtin_ctzll(t2);
            t2 &= t2 - 1;
            for (int d = 0; d < 4; d++) {
                State nx; int winner;
                if (!applyMove(s, from, d, nx, winner)) continue;
                if (__builtin_popcountll(nx.cur) < PMIN) continue;
                if (__builtin_popcountll(nx.opp) < PMIN) continue;
                moves++;
                bool dup = false;
                for (int j = 0; j < nch; j++)
                    if (ch[j].cur == nx.cur && ch[j].opp == nx.opp) { dup = true; break; }
                if (dup) { dupCfg += o; continue; }
                if (nch < 80) ch[nch++] = nx;
                const State c = canonical(nx);
                const uint8_t v = getV(rankgenq::stateIndex(c.cur, c.opp, c.ban));
                if (v == 1) pW += o; else if (v == 2) pL += o; else pD += o;
            }
        }
        moveCount += o * (uint64_t)moves;
        edgeCount += o * (uint64_t)nch;
    }
    nPos = edgeCount + 1;   // the initial position has no previous configuration, so it is counted separately
    const auto t2 = std::chrono::steady_clock::now();

    std::printf("========================================\n");
    std::printf(" position count for %d x %d, capture threshold %d\n", N, M, Q);
    std::printf("========================================\n");
    std::printf("representatives (modulo reflection) : %llu\n", (unsigned long long)states.size());
    std::printf("reachable states (unreflected)      : %llu\n", (unsigned long long)nState);
    std::printf("  wins / losses / draws             : %llu / %llu / %llu\n",
                (unsigned long long)sW, (unsigned long long)sL, (unsigned long long)sD);
    std::printf("----------------------------------------\n");
    std::printf("positions (edges + initial position): %llu\n", (unsigned long long)nPos);
    std::printf("  for reference, legal moves        : %llu\n", (unsigned long long)moveCount);
    std::printf("  ... reaching the same configuration: %llu %s\n", (unsigned long long)dupCfg,
                dupCfg ? "** moves and configurations differ" : "(they agree)");
    std::printf("  leading to win / loss / draw      : %llu / %llu / %llu\n",
                (unsigned long long)pW, (unsigned long long)pL, (unsigned long long)pD);
    std::printf("----------------------------------------\n");
    std::printf("all indexed states (forbidden-move encoding): %llu\n", (unsigned long long)TOTAL);
    std::printf("enumeration %.2f s / counting %.2f s\n",
                std::chrono::duration<double>(t1 - t0).count(),
                std::chrono::duration<double>(t2 - t1).count());
    std::printf("========================================\n");
    return 0;
}
