// Complete retrograde analysis over the whole indexed state space.
//
// ## Difference from the hash-table approach
//
// Earlier solvers kept states in a hash table at 36 bytes each (8 for the key,
// 4 for the index, 12 for the state, plus slack at a load factor of 0.5). At a
// billion states that is 36 GB, more than the machine has.
//
// With capture threshold one the game ends the moment a marker is removed, so
// **a non-terminal state always has p markers on each side**. With the count
// fixed, the configuration can be ranked directly and no hash table is needed at
// all. Two bits suffice for the value and one byte for the retrograde counter.
//
// ## Retrograde analysis
//
// WIN and LOSS are propagated backwards from the terminal positions. Whatever is
// still UNKNOWN once the propagation stops is a draw.
//
// "No winning move found" in a depth-limited search does not mean a draw.
// Handling repetition correctly, that is, revisiting the same board with the same
// side to move and the same forbidden move, needs a retrograde analysis that uses
// the finiteness of the reachable set.
//
// ## Why no predecessor lists
//
// Lists of predecessors cost memory. Instead the sweep is iterated, picking up
// states whose counter has reached zero on the next pass. The number of sweeps
// grows with the length of the decisive line, but each sweep is linear, so the
// whole run stays within a practical time.
//
// Build: g++ -O2 -std=c++17 -o build/solveidx src/solveidx.cpp
// Run  : ./build/solveidx <height> <width> <markers per player>
#include "rankgen.h"
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static int NR, NC, NCELL, NPIECE;
static const int DR[4] = {-1, 1, 0, 0};
static const int DC[4] = {0, 0, -1, 1};
static const uint8_t NO_MOVE = 0xFF;

static inline bool inBoard(int r, int c) { return r >= 0 && r < NR && c >= 0 && c < NC; }

// Applies a move. winner: 0 = game continues, 1 = the player to move removed an
// opponent marker, 2 = the player to move removed one of their own.
// The same logic as in solvepos.cpp / gapprobe.cpp (already verified).
static inline bool applyMove(uint64_t cur, uint64_t opp, uint8_t ban,
                             int from, int d,
                             uint64_t &ncur, uint64_t &nopp, uint8_t &nban,
                             int &winner) {
  if (!((cur >> from) & 1ULL)) return false;
  if (ban != NO_MOVE && ban == (uint8_t)((from << 2) | d)) return false;
  const uint64_t occ = cur | opp;
  const int dr = DR[d], dc = DC[d];
  int line[64], len = 1;
  line[0] = from;
  int rr = from / NC + dr, cc = from % NC + dc;
  int dest = inBoard(rr, cc) ? rr * NC + cc : -1;
  while (dest >= 0 && ((occ >> dest) & 1ULL)) {
    line[len++] = dest;
    rr = dest / NC + dr; cc = dest % NC + dc;
    dest = inBoard(rr, cc) ? rr * NC + cc : -1;
  }
  ncur = cur; nopp = opp;
  winner = 0;
  int hole = dest;
  for (int i = len - 1; i >= 0; i--) {
    const uint64_t bit = 1ULL << line[i];
    if (ncur & bit) {
      ncur ^= bit;
      if (hole < 0) winner = 2; else ncur |= 1ULL << hole;
    } else {
      nopp ^= bit;
      if (hole < 0) winner = 1; else nopp |= 1ULL << hole;
    }
    hole = line[i];
  }
  if (winner != 0) { nban = NO_MOVE; return true; }
  // If an opponent marker came to rest on the landing square, the move that
  // pushes it back is the forbidden one.
  nban = NO_MOVE;
  if (dest >= 0 && ((nopp >> dest) & 1ULL)) nban = (uint8_t)((dest << 2) | (d ^ 1));
  // **Swap the side to move.** A state always keeps the player to move in cur,
  // so after a move the opponent becomes that player. Forgetting this builds a
  // tree in which one side moves forever, and the retrograde analysis is
  // meaningless.
  const uint64_t t = ncur; ncur = nopp; nopp = t;
  return true;
}

// Collapses a forbidden move that can no longer be played: if the square it
// starts from holds no marker of the player to move, the restriction is vacuous.
// This keeps one position from being counted under several forbidden-move values.
static inline uint8_t killDeadBan(uint64_t cur, uint8_t ban) {
  if (ban != NO_MOVE && !((cur >> (ban >> 2)) & 1ULL)) return NO_MOVE;
  return ban;
}

enum : uint8_t { UNKNOWN = 0, WIN = 1, LOSS = 2 };

int main(int argc, char **argv) {
  NR = argc > 1 ? atoi(argv[1]) : 4;
  NC = argc > 2 ? atoi(argv[2]) : 4;
  NPIECE = argc > 3 ? atoi(argv[3]) : NC;
  NCELL = NR * NC;
  rankgen::init(NR, NC, NPIECE);

  const uint64_t TOTAL = rankgen::TOTAL_CNT;
  printf("board %dx%d, %d markers each, capture threshold 1\n", NR, NC, NPIECE);
  printf("states  : %llu\n", (unsigned long long)TOTAL);
  printf("memory  : %.2f GiB of values + %.2f GiB of counters\n\n",
         TOTAL * 2.0 / 8 / 1073741824.0, TOTAL / 1073741824.0);
  fflush(stdout);

  auto t0 = std::chrono::steady_clock::now();

  // value[i]: two bits holding UNKNOWN / WIN / LOSS
  std::vector<uint8_t> value(TOTAL / 4 + 1, 0);
  bool loaded = false;
  if (const char *in = getenv("LOAD_VALUES")) {
    FILE *fp = fopen(in, "rb");
    if (fp) {
      const size_t got = fread(value.data(), 1, value.size(), fp);
      fclose(fp);
      if (got == value.size()) {
        loaded = true;
        printf("values read from %s\n", in);
      } else {
        fprintf(stderr, "size read does not match: %zu != %zu\n",
                got, value.size());
        return 1;
      }
    }
  }
  auto getV = [&](uint64_t i) -> uint8_t {
    return (value[i >> 2] >> ((i & 3) * 2)) & 3;
  };
  auto setV = [&](uint64_t i, uint8_t v) {
    const uint64_t w = i >> 2;
    const int sh = (i & 3) * 2;
    value[w] = (uint8_t)((value[w] & ~(3 << sh)) | (v << sh));
  };

  // cnt[i]: how many successors are still UNKNOWN. At zero they are all wins for
  // the opponent, so the state is a LOSS.
  std::vector<uint8_t> cnt(TOTAL, 0);

  // ## First pass: count the legal moves of each state and mark immediate wins
  uint64_t nWin = 0, nLoss = 0;
  for (uint64_t i = 0; loaded ? false : i < TOTAL; i++) {
    uint64_t cur, opp; uint8_t ban;
    rankgen::stateUnindex(i, cur, opp, ban);
    // A self-removing move is never chosen, so it is not counted as a child.
    // A position offering nothing else is a loss, since every move scores for the
    // opponent. Getting this wrong leaves such positions UNKNOWN for ever and
    // reports them as draws.
    int child = 0;
    bool immediateWin = false;
    for (int from = 0; from < NCELL && !immediateWin; from++) {
      if (!((cur >> from) & 1ULL)) continue;
      for (int d = 0; d < 4; d++) {
        uint64_t nc2, no2; uint8_t nb2; int w;
        if (!applyMove(cur, opp, ban, from, d, nc2, no2, nb2, w)) continue;
        if (w == 1) { immediateWin = true; break; }   // can remove an opponent marker
        if (w == 2) continue;                          // a self-removing move is never chosen
        child++;
      }
    }
    if (immediateWin) { setV(i, WIN); nWin++; cnt[i] = 0; }
    else if (child == 0) { setV(i, LOSS); nLoss++; cnt[i] = 0; }  // no move to play: a loss
    else cnt[i] = (uint8_t)(child > 255 ? 255 : child);
    if ((i & 0xFFFFFFF) == 0 && i) {
      printf("  first pass %llu / %llu\n", (unsigned long long)i, (unsigned long long)TOTAL);
      fflush(stdout);
    }
  }
  auto t1 = std::chrono::steady_clock::now();
  printf("first pass done: %llu immediate wins, %llu with no move   %.1f s\n",
         (unsigned long long)nWin, (unsigned long long)nLoss,
         std::chrono::duration<double>(t1 - t0).count());
  fflush(stdout);

  // ## Second pass onwards: sweep until the propagation stops
  //
  //   a single LOSS among the successors makes the state a WIN
  //   all successors WIN makes it a LOSS (cnt reaches zero)
  //
  // With no predecessor lists, the whole space is swept until nothing changes.
  int round = 0;
  for (; !loaded;) {
    round++;
    uint64_t changed = 0;
    for (uint64_t i = 0; i < TOTAL; i++) {
      if (getV(i) != UNKNOWN) continue;
      uint64_t cur, opp; uint8_t ban;
      rankgen::stateUnindex(i, cur, opp, ban);
      int unknownLeft = 0;
      bool anyLoss = false;
      for (int from = 0; from < NCELL && !anyLoss; from++) {
        if (!((cur >> from) & 1ULL)) continue;
        for (int d = 0; d < 4; d++) {
          uint64_t nc2, no2; uint8_t nb2; int w;
          if (!applyMove(cur, opp, ban, from, d, nc2, no2, nb2, w)) continue;
          if (w == 1) { anyLoss = true; break; }        // an immediate win, already handled in the first pass
          if (w == 2) continue;                          // self-removal is never chosen; it scores for the opponent
          nb2 = killDeadBan(nc2, nb2);
          const uint64_t j = rankgen::stateIndex(nc2, no2, nb2);
          const uint8_t v = getV(j);
          if (v == LOSS) { anyLoss = true; break; }      // there is a move that loses for the opponent
          if (v == UNKNOWN) unknownLeft++;
        }
      }
      if (anyLoss) { setV(i, WIN); nWin++; changed++; }
      else if (unknownLeft == 0) { setV(i, LOSS); nLoss++; changed++; }
    }
    auto t2 = std::chrono::steady_clock::now();
    printf("  sweep %d: %llu changed, %llu wins, %llu losses   %.1f s\n",
           round, (unsigned long long)changed,
           (unsigned long long)nWin, (unsigned long long)nLoss,
           std::chrono::duration<double>(t2 - t0).count());
    fflush(stdout);
    if (!changed) break;
  }

  // When values are loaded the counters are not restored, so recount.
  if (loaded) {
    nWin = nLoss = 0;
    for (uint64_t i = 0; i < TOTAL; i++) {
      const uint8_t v = getV(i);
      if (v == WIN) nWin++;
      else if (v == LOSS) nLoss++;
    }
  }

  // ## Verdict for the initial position
  uint64_t F = 0, S = 0;
  for (int c = 0; c < NPIECE && c < NC; c++) {
    S |= 1ULL << (0 * NC + c);
    F |= 1ULL << ((NR - 1) * NC + c);
  }
  const uint64_t start = rankgen::stateIndex(F, S, NO_MOVE);
  const uint8_t sv = getV(start);

  // ## Saving the values
  //
  // Solving 5x5 takes three hours. Re-solving it for every spot check is not
  // practical, so the result is written to a file.
  if (const char *out = getenv("SAVE_VALUES")) {
    FILE *fp = fopen(out, "wb");
    if (fp) {
      fwrite(value.data(), 1, value.size(), fp);
      fclose(fp);
      printf("values written to %s (%.2f GiB)\n",
             out, value.size() / 1073741824.0);
    } else {
      fprintf(stderr, "failed to save: %s\n", out);
    }
  }

  // ## Output for spot checks
  //
  // Reads indices from standard input and prints the value of each. Used to
  // compare against the independent verdicts of sample5x5.
  if (getenv("DUMP_INDEX")) {
    unsigned long long qq;
    while (scanf("%llu", &qq) == 1) {
      const uint64_t q = (uint64_t)qq;
      if (q >= TOTAL) { printf("%llu X\n", (unsigned long long)q); continue; }
      const uint8_t v = getV(q);
      printf("%llu %c\n", (unsigned long long)q,
             v == WIN ? 'W' : v == LOSS ? 'L' : 'D');
    }
    fflush(stdout);
  }

  const uint64_t nDraw = TOTAL - nWin - nLoss;
  printf("\n=== result ===\n");
  printf("wins   : %llu\n", (unsigned long long)nWin);
  printf("losses : %llu\n", (unsigned long long)nLoss);
  printf("draws  : %llu\n", (unsigned long long)nDraw);
  printf("initial position: %s\n",
         sv == WIN ? "Black wins" : sv == LOSS ? "White wins" : "draw");
  auto t3 = std::chrono::steady_clock::now();
  printf("time   : %.1f s\n", std::chrono::duration<double>(t3 - t0).count());
  return 0;
}
