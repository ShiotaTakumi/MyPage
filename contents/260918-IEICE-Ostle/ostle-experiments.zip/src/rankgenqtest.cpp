// Checks that the ranking in rankgenq.h is a bijection.
//
//  (1) index -> position -> index is the identity (exhaustively, or sampled)
//  (2) the total number of states matches the value from binomials
//  (3) for q=1, every index agrees with rankgen.h
//      (for q=1 the blocks collapse to one, so the numbering must stay
//      compatible with the earlier results)
#include "rankgen.h"
#include "rankgenq.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>

static uint64_t binomOf(int n, int k) {
  if (k < 0 || k > n) return 0;
  uint64_t r = 1;
  for (int i = 0; i < k; i++) r = r * (n - i) / (i + 1);
  return r;
}

int main(int argc, char** argv) {
  const int NR = argc > 1 ? atoi(argv[1]) : 4;
  const int NC = argc > 2 ? atoi(argv[2]) : 3;
  const int NP = argc > 3 ? atoi(argv[3]) : NC;
  const int Q  = argc > 4 ? atoi(argv[4]) : 1;
  const uint64_t STEP = argc > 5 ? strtoull(argv[5], nullptr, 10) : 1;
  rankgenq::init(NR, NC, NP, Q);
  const int NCELL = NR * NC;
  const uint64_t TOTAL = rankgenq::TOTAL_CNT;

  // (2) check the total against binomials
  uint64_t expect = 0;
  const int PMIN = NP - Q + 1;
  for (int a = PMIN; a <= NP; a++)
    for (int b = PMIN; b <= NP; b++)
      expect += binomOf(NCELL, a) * binomOf(NCELL - a, b) * (4ULL * a + 1);
  printf("board %dx%d, %d markers each, capture threshold %d\n", NR, NC, NP, Q);
  printf("  states       : %llu\n", (unsigned long long)TOTAL);
  printf("  from binomials: %llu  -> %s\n", (unsigned long long)expect,
         TOTAL == expect ? "match" : "** MISMATCH");
  if (TOTAL != expect) return 1;

  // per-block breakdown
  for (int a = PMIN; a <= NP; a++)
    for (int b = PMIN; b <= NP; b++)
      printf("  block(%d,%d) first %14llu  count %14llu\n", a, b,
             (unsigned long long)rankgenq::SEC_OFF[a][b],
             (unsigned long long)rankgenq::SEC_CNT[a][b]);

  // (1) round trip
  uint64_t checked = 0, bad = 0;
  for (uint64_t i = 0; i < TOTAL; i += STEP) {
    uint64_t cur, opp; uint8_t ban;
    rankgenq::stateUnindex(i, cur, opp, ban);
    if (__builtin_popcountll(cur & opp)) { bad++; continue; }   // overlapping markers would be a bug
    const uint64_t back = rankgenq::stateIndex(cur, opp, ban);
    if (back != i) { if (bad < 5) printf("  ** round trip failed %llu -> %llu\n",
                                        (unsigned long long)i, (unsigned long long)back); bad++; }
    checked++;
  }
  printf("  round trip   : %llu checked / %llu mismatched -> %s\n",
         (unsigned long long)checked, (unsigned long long)bad, bad ? "** NG" : "OK");
  if (bad) return 1;

  // (3) for q=1 the indices must agree with rankgen.h exactly
  if (Q == 1) {
    rankgen::init(NR, NC, NP);
    if (rankgen::TOTAL_CNT != TOTAL) { printf("  ** total differs from rankgen\n"); return 1; }
    uint64_t d = 0, n = 0;
    for (uint64_t i = 0; i < TOTAL; i += STEP) {
      uint64_t cur, opp; uint8_t ban;
      rankgenq::stateUnindex(i, cur, opp, ban);
      if (rankgenq::stateIndex(cur, opp, ban) != rankgen::stateIndex(cur, opp, ban)) d++;
      n++;
    }
    printf("  vs rankgen   : %llu checked / %llu differed -> %s\n",
           (unsigned long long)n, (unsigned long long)d, d ? "** NG" : "OK");
    if (d) return 1;
  }
  printf("  => all checks passed\n\n");
  return 0;
}
