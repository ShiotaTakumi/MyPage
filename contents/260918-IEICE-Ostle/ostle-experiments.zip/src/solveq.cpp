// Complete retrograde analysis for capture threshold q on hole-free boards.
// The whole state space is indexed, and the states are split into blocks.
//
// ## Difference from solveidx.cpp
//
// solveidx only handles capture threshold one. There the game ends the moment a
// marker is removed, so every non-terminal position has p markers on each side
// and the marker count could be fixed in the numbering.
//
// With threshold q the game continues after a capture. A player loses once q of
// their markers have been removed, that is, once the count drops to p-q. Hence
// both counts are at least PMIN = p-q+1 in a non-terminal position, and the pair
// (markers of the player to move a, markers of the opponent b) takes q^2 values.
// The numbering is provided by rankgenq.h.
//
// ## Group the blocks by total marker count and solve the smallest first
//
// Markers are only ever removed, so the total s = a+b never grows. A move that
// captures nothing maps (a,b) -> (b,a) and keeps s; a capture or a self-removing
// move decreases s by one. Only blocks with the same s depend on each other.
//
//   s = 2p-2 : (p-1,p-1)                ... solved first
//   s = 2p-1 : (p,p-1) and (p-1,p)      ... one group of two
//   s = 2p   : (p,p)                    ... solved last
//
// Solving the groups in increasing order of s means each sweep only has to scan
// the group currently being solved.
//
// ## Running on 28 cores
//
// Within a sweep the states are independent, and a value changes only from
// UNKNOWN to WIN or LOSS, never back. So a thread that misses another thread's
// write simply reads the older value (UNKNOWN) and never settles a state too
// early; the missed update is picked up by the next sweep. The termination test
// is sound for the same reason: a sweep that makes no change performs no write,
// so every read in it is current.
//
// Packing values two bits at a time would break this, because four neighbouring
// states share a byte and concurrent writes would lose updates. Values are
// therefore stored **one byte per state**. For 5x5 with threshold two this grows
// the array from 6.60 GiB to 26.42 GiB, which buys an order of magnitude in speed.
//
// ## No counter array
//
// solveidx allocates cnt[] at one byte per state, but only writes it in the first
// pass and never reads it in the propagation loop, which recounts the children of
// each state every time. That was 16.11 GiB of pure waste, so it is not allocated
// here.
//
// ## How this is verified
//
// With q=1 the blocks collapse to the single block (p,p) and the indices from
// rankgenq coincide exactly with rankgen. So **reproducing the known values of
// solveidx with q=1 serves as a regression test**.
//
// The move logic is copied verbatim from src/solveidx.cpp.
//
// Build: g++ -O2 -std=c++17 -o build/solveq src/solveq.cpp
// Run  : ./build/solveq <height> <width> <markers per player> <q>
#include "rankgenq.h"
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
#include <thread>
#include <atomic>

static int NR, NC, NCELL, NPIECE, Q, PMIN;
static const int DR[4] = {-1, 1, 0, 0};
static const int DC[4] = {0, 0, -1, 1};
static const uint8_t NO_MOVE = 0xFF;

static inline bool inBoard(int r, int c) { return r >= 0 && r < NR && c >= 0 && c < NC; }

// Applies a move. winner: 0 = game continues, 1 = the player to move removed an
// opponent marker, 2 = the player to move removed one of their own.
// The same logic as in solvepos.cpp / gapprobe.cpp (already verified).
static inline bool applyMove(uint64_t cur, uint64_t opp, uint8_t ban,
                             int from, int d,
                             uint64_t &ncur, uint64_t &nopp, uint8_t &nban,
                             int &winner) {
  if (!((cur >> from) & 1ULL)) return false;
  if (ban != NO_MOVE && ban == (uint8_t)((from << 2) | d)) return false;
  const uint64_t occ = cur | opp;
  const int dr = DR[d], dc = DC[d];
  int line[64], len = 1;
  line[0] = from;
  int rr = from / NC + dr, cc = from % NC + dc;
  int dest = inBoard(rr, cc) ? rr * NC + cc : -1;
  while (dest >= 0 && ((occ >> dest) & 1ULL)) {
    line[len++] = dest;
    rr = dest / NC + dr; cc = dest % NC + dc;
    dest = inBoard(rr, cc) ? rr * NC + cc : -1;
  }
  ncur = cur; nopp = opp;
  winner = 0;
  int hole = dest;
  for (int i = len - 1; i >= 0; i--) {
    const uint64_t bit = 1ULL << line[i];
    if (ncur & bit) {
      ncur ^= bit;
      if (hole < 0) winner = 2; else ncur |= 1ULL << hole;
    } else {
      nopp ^= bit;
      if (hole < 0) winner = 1; else nopp |= 1ULL << hole;
    }
    hole = line[i];
  }
  if (winner != 0) { nban = NO_MOVE; return true; }
  // If an opponent marker came to rest on the landing square, the move that
  // pushes it back is the forbidden one.
  nban = NO_MOVE;
  if (dest >= 0 && ((nopp >> dest) & 1ULL)) nban = (uint8_t)((dest << 2) | (d ^ 1));
  // **Swap the side to move.** A state always keeps the player to move in cur,
  // so after a move the opponent becomes that player. Forgetting this builds a
  // tree in which one side moves forever, and the retrograde analysis is
  // meaningless.
  const uint64_t t = ncur; ncur = nopp; nopp = t;
  return true;
}

// Collapses a forbidden move that can no longer be played: if the square it
// starts from holds no marker of the player to move, the restriction is vacuous.
// This keeps one position from being counted under several forbidden-move values.
static inline uint8_t killDeadBan(uint64_t cur, uint8_t ban) {
  if (ban != NO_MOVE && !((cur >> (ban >> 2)) & 1ULL)) return NO_MOVE;
  return ban;
}

enum : uint8_t { UNKNOWN = 0, WIN = 1, LOSS = 2 };

int main(int argc, char **argv) {
  NR = argc > 1 ? atoi(argv[1]) : 4;
  NC = argc > 2 ? atoi(argv[2]) : 4;
  NPIECE = argc > 3 ? atoi(argv[3]) : NC;
  Q = argc > 4 ? atoi(argv[4]) : 1;
  NCELL = NR * NC;
  PMIN = NPIECE - Q + 1;
  if (PMIN < 1) { fprintf(stderr, "q exceeds the number of markers\n"); return 1; }
  rankgenq::init(NR, NC, NPIECE, Q);
  const uint64_t TOTAL = rankgenq::TOTAL_CNT;

  printf("board %dx%d, %d markers each, capture threshold %d\n", NR, NC, NPIECE, Q);
  printf("markers when non-terminal : %d to %d (losing %d of them loses the game)\n", PMIN, NPIECE, Q);
  printf("states                    : %llu\n", (unsigned long long)TOTAL);
  printf("memory                    : %.2f GiB of values (one byte per state, no counter array)\n",
         TOTAL / 1073741824.0);
  fflush(stdout);

  const auto t0 = std::chrono::steady_clock::now();
  // One byte per state, so that a parallel write cannot corrupt its neighbours.
  std::vector<uint8_t> value(TOTAL, 0);
  uint8_t* const V = value.data();
  auto getV = [&](uint64_t i) -> uint8_t { return V[i]; };
  auto setV = [&](uint64_t i, uint8_t v) { V[i] = v; };

  int NTH = (int)std::thread::hardware_concurrency();
  if (const char* e = getenv("THREADS")) NTH = atoi(e);
  if (NTH < 1) NTH = 1;
  printf("threads                   : %d\n\n", NTH);
  fflush(stdout);
  // Splits [lo,hi) into NTH parts run in parallel. f(begin, end) writes only
  // within its own range.
  auto parallelFor = [&](uint64_t lo, uint64_t hi, auto&& f) {
    std::vector<std::thread> th;
    const uint64_t n = hi - lo;
    for (int k = 0; k < NTH; k++) {
      const uint64_t b = lo + n * (uint64_t)k / NTH, e = lo + n * (uint64_t)(k + 1) / NTH;
      if (b < e) th.emplace_back([&f, b, e, k] { f(k, b, e); });
    }
    for (auto& x : th) x.join();
  };

  // Applies a move and returns the next position (with the side to move already
  // swapped) together with any immediate outcome.
  //   0 = illegal, 1 = ordinary child, 2 = playing it wins at once,
  //   3 = playing it loses at once
  auto step = [&](uint64_t cur, uint64_t opp, uint8_t ban, int from, int d,
                  uint64_t &nc, uint64_t &no, uint8_t &nb) -> int {
    int w;
    if (!applyMove(cur, opp, ban, from, d, nc, no, nb, w)) return 0;
    if (w != 0) {
      // applyMove assumes capture threshold one and returns without swapping
      // when it considers the game over. For q>=2 the game continues, so the
      // swap is done here. A move that pushes a marker off the board cannot be
      // undone in one move, so no forbidden move is recorded (nban stays
      // NO_MOVE).
      const uint64_t t = nc; nc = no; no = t;
      nb = NO_MOVE;
    }
    // After the swap: nc holds the markers of the new player to move, no those
    // of the opponent.
    if (__builtin_popcountll(nc) < PMIN) return 2;   // the opponent has lost q markers: the mover wins
    if (__builtin_popcountll(no) < PMIN) return 3;   // the mover has lost q markers: the mover loses
    nb = killDeadBan(nc, nb);
    return 1;
  };

  uint64_t nWin = 0, nLoss = 0;
  int totalRounds = 0;

  // Solve the groups in increasing order of the total marker count s. Blocks
  // sharing an s occupy a contiguous range of indices.
  for (int s = 2 * PMIN; s <= 2 * NPIECE; s++) {
    uint64_t lo = UINT64_MAX, hi = 0; int nsec = 0;
    for (int a = PMIN; a <= NPIECE; a++) {
      const int b = s - a;
      if (b < PMIN || b > NPIECE) continue;
      lo = std::min(lo, rankgenq::SEC_OFF[a][b]);
      hi = std::max(hi, rankgenq::SEC_OFF[a][b] + rankgenq::SEC_CNT[a][b]);
      nsec++;
    }
    if (!nsec) continue;
    printf("--- group with total marker count %d (%d blocks, %llu states) ---\n",
           s, nsec, (unsigned long long)(hi - lo));
    fflush(stdout);

    // First pass: mark the immediate wins, and mark as a loss any position with
    // no playable move once the immediately losing ones are excluded.
    std::vector<uint64_t> tw(NTH, 0), tl(NTH, 0);
    parallelFor(lo, hi, [&](int k, uint64_t b, uint64_t e) {
      uint64_t w = 0, l = 0;
      for (uint64_t i = b; i < e; i++) {
        uint64_t cur, opp; uint8_t ban;
        rankgenq::stateUnindex(i, cur, opp, ban);
        int child = 0; bool immediateWin = false;
        for (int from = 0; from < NCELL && !immediateWin; from++) {
          if (!((cur >> from) & 1ULL)) continue;
          for (int d = 0; d < 4; d++) {
            uint64_t nc, no; uint8_t nb;
            const int r = step(cur, opp, ban, from, d, nc, no, nb);
            if (r == 0) continue;
            if (r == 2) { immediateWin = true; break; }
            if (r == 3) continue;               // an immediately losing move is never chosen
            child++;
          }
        }
        if (immediateWin) { setV(i, WIN); w++; }
        else if (child == 0) { setV(i, LOSS); l++; }   // no move to play: a loss
      }
      tw[k] = w; tl[k] = l;
    });
    uint64_t gw = 0, gl = 0;
    for (int k = 0; k < NTH; k++) { gw += tw[k]; gl += tl[k]; }
    nWin += gw; nLoss += gl;
    printf("  first pass: %llu immediate wins, %llu with no move   %.1f s\n",
           (unsigned long long)gw, (unsigned long long)gl,
           std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    fflush(stdout);

    // Propagation. Only this group has to be scanned; the groups below are
    // already solved.
    int round = 0;
    while (true) {
      round++; totalRounds++;
      std::vector<uint64_t> cw(NTH, 0), cl(NTH, 0);
      parallelFor(lo, hi, [&](int k, uint64_t b, uint64_t e) {
        uint64_t w = 0, l = 0;
        for (uint64_t i = b; i < e; i++) {
          if (getV(i) != UNKNOWN) continue;
          uint64_t cur, opp; uint8_t ban;
          rankgenq::stateUnindex(i, cur, opp, ban);
          int unknownLeft = 0; bool anyLoss = false;
          for (int from = 0; from < NCELL && !anyLoss; from++) {
            if (!((cur >> from) & 1ULL)) continue;
            for (int d = 0; d < 4; d++) {
              uint64_t nc, no; uint8_t nb;
              const int r = step(cur, opp, ban, from, d, nc, no, nb);
              if (r == 0 || r == 3) continue;
              if (r == 2) { anyLoss = true; break; }
              const uint8_t v = getV(rankgenq::stateIndex(nc, no, nb));
              if (v == LOSS) { anyLoss = true; break; }
              if (v == UNKNOWN) unknownLeft++;
            }
          }
          if (anyLoss) { setV(i, WIN); w++; }
          else if (unknownLeft == 0) { setV(i, LOSS); l++; }
        }
        cw[k] = w; cl[k] = l;
      });
      uint64_t changed = 0;
      for (int k = 0; k < NTH; k++) { nWin += cw[k]; nLoss += cl[k]; changed += cw[k] + cl[k]; }
      printf("    sweep %d: %llu changed   %.1f s\n", round, (unsigned long long)changed,
             std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
      fflush(stdout);
      if (!changed) break;
    }
  }

  // the initial position
  uint64_t F = 0, S = 0;
  for (int c = 0; c < NPIECE && c < NC; c++) {
    S |= 1ULL << (0 * NC + c);
    F |= 1ULL << ((NR - 1) * NC + c);
  }
  const uint64_t start = rankgenq::stateIndex(F, S, NO_MOVE);
  const uint8_t sv = getV(start);

  if (const char *out = getenv("SAVE_VALUES")) {
    FILE *fp = fopen(out, "wb");
    if (fp) { fwrite(value.data(), 1, value.size(), fp); fclose(fp);
      printf("values written to %s (%.2f GiB)\n", out, value.size() / 1073741824.0); }
  }

  printf("\n=== result ===\n");
  printf("wins   : %llu\n", (unsigned long long)nWin);
  printf("losses : %llu\n", (unsigned long long)nLoss);
  printf("draws  : %llu\n", (unsigned long long)(TOTAL - nWin - nLoss));
  printf("initial position: %s\n",
         sv == WIN ? "Black wins" : sv == LOSS ? "White wins" : "draw");
  printf("sweeps : %d\n", totalRounds);
  printf("time   : %.1f s\n",
         std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
  return 0;
}
