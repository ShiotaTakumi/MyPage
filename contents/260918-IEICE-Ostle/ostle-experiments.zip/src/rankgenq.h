// Ranking extended to positions where the two players have different marker
// counts, so that any capture threshold q can be handled.
//
// ## Difference from rankgen.h
//
// With capture threshold one, a non-terminal position always has p markers on
// each side, so rankgen.h could fix the marker count. With threshold q the game
// continues after a capture, so positions with fewer markers are non-terminal
// too.
//
//   A player loses once q of their markers have been removed, that is, once the
//   count drops to p-q. Hence both counts lie between p-q+1 and p in every
//   non-terminal position, and the pair
//   (markers of the player to move a, markers of the opponent b) takes only
//   q^2 values.
//
// Each such pair (a,b) is called a **block**, and each block is given a
// contiguous range of indices. For q=1 there is a single block (p,p) and the
// numbering coincides exactly with rankgen.h.
//
// ## The blocks are layered
//
// Markers are only ever removed, so transitions between blocks go one way.
//
//   (5,5) -> (5,5) / (5,4) / (4,5)      ... for 5x5 with capture threshold two
//   (5,4) -> (4,5) / game over
//   (4,5) -> (5,4) / game over
//   (4,4) -> (4,4) / game over
//
// Solving the blocks in increasing order of the total marker count means the
// retrograde sweep only ever touches the block being solved. This is what
// determines the memory footprint.
#pragma once
#include <cstdint>
#include <cstdio>

namespace rankgenq {

static int NR = 5, NC = 5, NCELL = 25, NPIECE = 5, Q = 1;
static int PMIN = 5;                       // smallest marker count allowed in a non-terminal position = NPIECE-Q+1
static uint64_t BINOM[64][16];
static uint64_t SEC_OFF[8][8];             // first index of block (a,b)
static uint64_t SEC_SECOND[8][8];          // C(NCELL-a, b)
static uint64_t SEC_CNT[8][8];             // number of states in the block
static uint64_t TOTAL_CNT;

inline uint64_t binom(int n, int k) {
  if (k < 0 || n < 0 || k > n || n >= 64 || k >= 16) return 0;
  return BINOM[n][k];
}

inline int banCnt(int a) { return 4 * a + 1; }

inline void init(int nr, int nc, int npiece, int q) {
  NR = nr; NC = nc; NCELL = nr * nc; NPIECE = npiece; Q = q;
  PMIN = NPIECE - Q + 1;
  for (int n = 0; n < 64; n++) {
    BINOM[n][0] = 1;
    for (int k = 1; k < 16; k++)
      BINOM[n][k] = (k > n) ? 0 : BINOM[n - 1][k - 1] + BINOM[n - 1][k];
  }
  // Lay out blocks with a smaller total marker count first; the retrograde
  // analysis can then solve them in this order.
  TOTAL_CNT = 0;
  for (int s = 2 * PMIN; s <= 2 * NPIECE; s++)
    for (int a = PMIN; a <= NPIECE; a++) {
      const int b = s - a;
      if (b < PMIN || b > NPIECE) continue;
      SEC_SECOND[a][b] = binom(NCELL - a, b);
      SEC_CNT[a][b] = binom(NCELL, a) * SEC_SECOND[a][b] * (uint64_t)banCnt(a);
      SEC_OFF[a][b] = TOTAL_CNT;
      TOTAL_CNT += SEC_CNT[a][b];
    }
}

// --- The next four are defined exactly as in rankgen.h; they simply take the
// --- marker count k as an argument. ---
inline uint64_t maskToRank(uint64_t mask) {
  uint64_t r = 0; int i = 1;
  while (mask) {
    const int p = __builtin_ctzll(mask);
    mask &= mask - 1;
    r += binom(p, i); i++;
  }
  return r;
}
inline uint64_t rankToMask(uint64_t r, int n, int k) {
  uint64_t mask = 0;
  for (int i = k; i >= 1; i--) {
    int p = i - 1;
    while (p + 1 <= n - 1 && binom(p + 1, i) <= r) p++;
    mask |= 1ULL << p;
    r -= binom(p, i);
    n = p;
  }
  return mask;
}
inline uint64_t compress(uint64_t mask, uint64_t occupied) {
  uint64_t out = 0; int idx = 0;
  for (int i = 0; i < NCELL; i++) {
    if ((occupied >> i) & 1ULL) continue;
    if ((mask >> i) & 1ULL) out |= 1ULL << idx;
    idx++;
  }
  return out;
}
inline uint64_t expand(uint64_t cmask, uint64_t occupied) {
  uint64_t out = 0; int idx = 0;
  for (int i = 0; i < NCELL; i++) {
    if ((occupied >> i) & 1ULL) continue;
    if ((cmask >> idx) & 1ULL) out |= 1ULL << i;
    idx++;
  }
  return out;
}

// Maps the forbidden move (from,dir) to 0..4a. "from" must hold a marker of
// the player to move.
inline uint32_t banRank(uint64_t cur, uint8_t ban) {
  if (ban == 0xFF) return 0;
  const int from = ban >> 2, d = ban & 3;
  const uint64_t below = cur & ((1ULL << from) - 1);
  return (uint32_t)(__builtin_popcountll(below) * 4 + d + 1);
}
inline uint8_t banUnrank(uint64_t cur, uint32_t br) {
  if (br == 0) return 0xFF;
  br--;
  const int idx = br / 4, d = br % 4;
  uint64_t m = cur;
  for (int i = 0; i < idx; i++) m &= m - 1;
  return (uint8_t)((__builtin_ctzll(m) << 2) | d);
}

inline uint64_t stateIndex(uint64_t cur, uint64_t opp, uint8_t ban) {
  const int a = __builtin_popcountll(cur), b = __builtin_popcountll(opp);
  const uint64_t pr = maskToRank(cur) * SEC_SECOND[a][b] + maskToRank(compress(opp, cur));
  return SEC_OFF[a][b] + pr * (uint64_t)banCnt(a) + banRank(cur, ban);
}

inline void stateUnindex(uint64_t idx, uint64_t &cur, uint64_t &opp, uint8_t &ban) {
  int a = 0, b = 0;
  for (int s = 2 * PMIN; s <= 2 * NPIECE; s++)
    for (int x = PMIN; x <= NPIECE; x++) {
      const int y = s - x;
      if (y < PMIN || y > NPIECE) continue;
      if (idx >= SEC_OFF[x][y] && idx < SEC_OFF[x][y] + SEC_CNT[x][y]) { a = x; b = y; }
    }
  const uint64_t loc = idx - SEC_OFF[a][b];
  const uint64_t pr = loc / banCnt(a);
  cur = rankToMask(pr / SEC_SECOND[a][b], NCELL, a);
  opp = expand(rankToMask(pr % SEC_SECOND[a][b], NCELL - a, b), cur);
  ban = banUnrank(cur, (uint32_t)(loc % banCnt(a)));
}

}  // namespace rankgenq
