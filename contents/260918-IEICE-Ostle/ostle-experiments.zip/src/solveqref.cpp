// Re-solves capture threshold q **sharing no code with solveq.cpp**.
//
// This is solve5x5ref.cpp (capture threshold one) generalised to threshold q.
// Only three things changed; the state handling, the normalisation and the
// retrograde analysis are untouched.
//
//   (1) applyMove: the position is kept, with the side to move swapped, even when
//       a marker is removed
//   (2) the outcome test is "fewer than PMIN markers" instead of "one removed"
//   (3) arguments: the third is now q and the fourth the state-count limit
//
// With q=1, PMIN = p and the behaviour is identical to the original solve5x5ref.
//
//
// ## Why a second implementation exists
//
// solveidx.cpp indexed the whole state space and found 5x5 to be a draw. But it
// carries its own numbering (rankgen.h) and its own applyMove. A checker built to
// the same design, verify5x5.cpp, would share both and so would not be an
// independent check.
//
// This file is instead built on solver6.cpp from the parent repository, which is
// already verified.
//
//   * state handling : hash table (no combinatorial ranking)
//   * scope          : **reachable states only**, not the whole space
//   * normalisation  : unified side to move, reflections, and collapsing of
//                      forbidden moves that can no longer be played
//   * retrograde     : the classical method, with an explicit list of predecessors
//
// Neither the way states are held nor the direction of the search matches
// solveidx, so a bug in one does not propagate to the other.
//
// ## Changes from solver6
//
// (1) The hash table now doubles automatically at a load factor of 0.5.
//     The original takes a fixed size in init and never resizes, so once the
//     number of states passes the capacity its linear probing degenerates and it
//     **burns CPU without making progress**. For 5x5 the reachable states run well
//     past a million, so this fix is essential.
//
// (2) Progress output was added. The run is long, and without it there is no way
//     to tell what is happening.
//
// src/solver6.cpp in the parent repository is untouched; it is only read.
//
// Build: g++ -O2 -std=c++17 -o build/solveqref src/solveqref.cpp
// Run  : ./build/solveqref <height> <width> <q> [state limit]
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

static int N = 4, M = 2, NCELL = 8;
static int Q = 1, PMIN = 2;   // PMIN = markers - Q + 1; below this the player has lost

static const int DR[4] = { -1, 1, 0, 0 };
static const int DC[4] = { 0, 0, -1, 1 };
// how a reflection maps the directions
static const int FLIP_V[4] = { 1, 0, 2, 3 };   // vertical flip: U<->D
static const int FLIP_H[4] = { 0, 1, 3, 2 };   // horizontal flip: L<->R

static inline bool inBoard(int r, int c) { return r >= 0 && r < N && c >= 0 && c < M; }

static const uint8_t NO_MOVE = 0xFF;

// ---------------------------------------------------------------------------
// State
//   cur : markers of the player to move
//   opp : markers of the opponent
//   ban : the forbidden move (source*4 + direction); NO_MOVE if none.
//         It records that playing this move would restore the previous board.
// ---------------------------------------------------------------------------
struct State {
    uint64_t cur, opp;
    uint8_t  ban;
    bool operator==(const State& o) const {
        return cur == o.cur && opp == o.opp && ban == o.ban;
    }
};

// lexicographic comparison, used to pick the representative
static inline bool stateLess(const State& a, const State& b) {
    if (a.cur != b.cur) return a.cur < b.cur;
    if (a.opp != b.opp) return a.opp < b.opp;
    return a.ban < b.ban;
}

// ---------------------------------------------------------------------------
// reflections
// ---------------------------------------------------------------------------
static inline uint64_t flipMask(uint64_t mask, bool h, bool v) {
    if (!h && !v) return mask;
    uint64_t out = 0;
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < M; c++) {
            if (!((mask >> (r * M + c)) & 1ULL)) continue;
            const int nr = v ? N - 1 - r : r;
            const int nc = h ? M - 1 - c : c;
            out |= 1ULL << (nr * M + nc);
        }
    }
    return out;
}

static inline uint8_t flipMove(uint8_t mv, bool h, bool v) {
    if (mv == NO_MOVE) return NO_MOVE;
    int src = mv >> 2, d = mv & 3;
    int r = src / M, c = src % M;
    if (h) { c = M - 1 - c; d = FLIP_H[d]; }
    if (v) { r = N - 1 - r; d = FLIP_V[d]; }
    return (uint8_t)(((r * M + c) << 2) | d);
}

// the lexicographically smallest of the four reflections is the representative
static inline State canonical(State s) {
    State best = s;
    for (int t = 1; t < 4; t++) {
        const bool h = t & 1, v = t & 2;
        State x{ flipMask(s.cur, h, v), flipMask(s.opp, h, v), flipMove(s.ban, h, v) };
        if (stateLess(x, best)) best = x;
    }
    return best;
}

// ---------------------------------------------------------------------------
// Collapses a forbidden move that can no longer be played.
//   If the square the forbidden move starts from holds no marker of the player
//   to move, that move could not be played anyway. Normalising it to NONE merges
//   states that differ only in history.
//   This is the reduction that pays off most in the collaborator's implementation.
// ---------------------------------------------------------------------------
static inline void normalizeBan(State& s) {
    if (s.ban == NO_MOVE) return;
    const int src = s.ban >> 2;
    if (!((s.cur >> src) & 1ULL)) s.ban = NO_MOVE;
}

// ---------------------------------------------------------------------------
// Applies a move, from the point of view of the player to move.
//   Returns true if the move is legal.
//   nextState is the state after swapping the side to move (cur/opp exchanged).
//   dropCur/dropOpp are the numbers of markers removed.
// ---------------------------------------------------------------------------
static inline bool applyMove(const State& s, int from, int d,
                             State& next, int& winner) {
    // winner: 0 = game continues, 1 = the player to move wins, 2 = they lose
    if (!((s.cur >> from) & 1ULL)) return false;
    if (s.ban != NO_MOVE && s.ban == (uint8_t)((from << 2) | d)) return false;

    const uint64_t occ = s.cur | s.opp;
    const int dr = DR[d], dc = DC[d];

    // Build the line to be pushed, starting with the marker being moved.
    int line[64], len = 1;
    line[0] = from;
    int rr = from / M + dr, cc = from % M + dc;
    int dest = inBoard(rr, cc) ? rr * M + cc : -1;
    while (dest >= 0 && ((occ >> dest) & 1ULL)) {
        line[len++] = dest;
        rr = dest / M + dr; cc = dest % M + dc;
        dest = inBoard(rr, cc) ? rr * M + cc : -1;
    }

    // Advance the line one square at a time, from its far end.
    // If a marker leaves the board the game is decided; when several would fall,
    // the colour of the nearer one decides the outcome.
    uint64_t ncur = s.cur, nopp = s.opp;
    winner = 0;
    int hole = dest;                   // the empty square beyond the line (-1 means off the board)
    for (int i = len - 1; i >= 0; i--) {
        const uint64_t bit = 1ULL << line[i];
        if (ncur & bit) {
            ncur ^= bit;
            if (hole < 0) winner = 2;  // own marker removed -> the player to move loses
            else ncur |= 1ULL << hole;
        } else {
            nopp ^= bit;
            if (hole < 0) winner = 1;  // opponent marker removed -> the player to move wins
            else nopp |= 1ULL << hole;
        }
        hole = line[i];
    }

    // With capture threshold q the game continues after a marker is removed, so
    // the position must not be discarded as it is for threshold one. A marker
    // pushed off the board cannot be restored in one move, so no forbidden move
    // is recorded.
    if (winner != 0) {
        next = State{ nopp, ncur, NO_MOVE };   // swap the side to move
        return true;
    }

    // The forbidden move as seen by the next player to move.
    // dest is the empty square at the head of the pushed line; moving the marker
    // that came to rest there back again is the move that restores the previous
    // board.
    //
    // Only the owner of that marker can play the reverse move, so the
    // restriction matters only when the marker on dest belongs to the next
    // player to move (nopp). Otherwise it would lapse on the next move, so it is
    // collapsed to NO_MOVE, merging states that differ only in history.
    // (This is the largest reduction in the collaborator's implementation.)
    uint8_t back = NO_MOVE;
    if (dest >= 0 && ((nopp >> dest) & 1ULL)) {
        back = (uint8_t)((dest << 2) | (d ^ 1));   // d^1 swaps U<->D and L<->R
    }

    next = State{ nopp, ncur, back };   // exchange the side to move
    return true;
}

// ---------------------------------------------------------------------------
// Hash table (open addressing)
// ---------------------------------------------------------------------------
static inline uint64_t mix64(uint64_t z) {
    z += 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

struct Table {
    std::vector<State>    keys;
    std::vector<uint32_t> vals;    // 0 = empty, otherwise id+1
    uint64_t mask;

    uint64_t count = 0;
    void init(uint64_t cap) {
        uint64_t n = 1;
        while (n < cap * 2) n <<= 1;
        keys.assign(n, State{0, 0, 0});
        vals.assign(n, 0);
        mask = n - 1;
        count = 0;
    }
    // Double the table once the load factor passes 0.5.
    // The original solver6 does not do this; past capacity its linear probing
    // degenerates and it burns CPU without making progress. Essential for 5x5.
    void grow() {
        std::vector<State> ok = std::move(keys);
        std::vector<uint32_t> ov = std::move(vals);
        const uint64_t n = (ok.size() ? ok.size() : 1) << 1;
        keys.assign(n, State{0, 0, 0});
        vals.assign(n, 0);
        mask = n - 1;
        for (size_t i = 0; i < ok.size(); i++) {
            if (!ov[i]) continue;
            uint64_t h = mix64(ok[i].cur ^ mix64(ok[i].opp) ^ ((uint64_t)ok[i].ban << 56)) & mask;
            while (vals[h]) h = (h + 1) & mask;
            keys[h] = ok[i]; vals[h] = ov[i];
        }
    }
    // Returns the id if present; otherwise inserts and assigns newId.
    uint32_t findOrInsert(const State& s, uint32_t newId, bool& isNew) {
        if ((count + 1) * 2 > keys.size()) grow();
        uint64_t h = mix64(s.cur ^ mix64(s.opp) ^ ((uint64_t)s.ban << 56)) & mask;
        while (true) {
            if (vals[h] == 0) {
                keys[h] = s; vals[h] = newId + 1; isNew = true; count++;
                return newId;
            }
            if (keys[h] == s) { isNew = false; return vals[h] - 1; }
            h = (h + 1) & mask;
        }
    }
    bool find(const State& s, uint32_t& id) const {
        uint64_t h = mix64(s.cur ^ mix64(s.opp) ^ ((uint64_t)s.ban << 56)) & mask;
        while (true) {
            if (vals[h] == 0) return false;
            if (keys[h] == s) { id = vals[h] - 1; return true; }
            h = (h + 1) & mask;
        }
    }
};

int main(int argc, char** argv) {
    if (argc >= 3) { N = std::atoi(argv[1]); M = std::atoi(argv[2]); }
    Q = (argc >= 4) ? std::atoi(argv[3]) : 1;
    PMIN = M - Q + 1;
    if (PMIN < 1) { std::fprintf(stderr, "q exceeds the number of markers\n"); return 1; }
    // The number of reachable states is not known in advance, so stop safely once
    // the limit is passed. This keeps the process from exhausting memory and
    // taking the machine down with it.
    uint64_t stateLimit = (argc >= 5) ? std::strtoull(argv[4], nullptr, 10) : 0;
    NCELL = N * M;
    if (N < 2) { std::fprintf(stderr, "n must be at least 2\n"); return 1; }
    if (NCELL > 63) { std::fprintf(stderr, "n*m must be at most 63\n"); return 1; }
    if (NCELL * 4 > 255) { std::fprintf(stderr, "n*m*4 exceeds 255\n"); return 1; }

    const auto t0 = std::chrono::steady_clock::now();

    // initial position (the first player occupies the bottom row)
    State init{ 0, 0, NO_MOVE };
    for (int c = 0; c < M; c++) {
        init.cur |= 1ULL << ((N - 1) * M + c);   // the player to move is the first player
        init.opp |= 1ULL << c;
    }
    init = canonical(init);

    Table table;
    table.init(1 << 20);

    std::vector<State>    states;
    std::vector<uint8_t>  result;    // 0 = unknown, 1 = the player to move wins, 2 = they lose
    std::vector<uint8_t>  degree;
    // Predecessors could be generated by inverting the move that produces a
    // state, avoiding an explicit list. But normalisation merges states, which
    // makes that inversion awkward, so an explicit list of predecessors is kept
    // instead; at 1/29 of the state count this is affordable.
    std::vector<std::vector<uint32_t>> preds;

    auto getId = [&](const State& s, bool& isNew) -> uint32_t {
        const uint32_t id = (uint32_t)states.size();
        const uint32_t got = table.findOrInsert(s, id, isNew);
        if (isNew) {
            states.push_back(s);
            result.push_back(0);
            degree.push_back(0);
            preds.push_back({});
        }
        return got;
    };

    bool dummy;
    const uint32_t initId = getId(init, dummy);

    std::vector<uint32_t> settled;
    uint64_t edgeCount = 0;

    // -----------------------------------------------------------------------
    // Stage 1: enumerate the reachable states
    // -----------------------------------------------------------------------
    bool aborted = false;
    for (size_t qi = 0; qi < states.size(); qi++) {
        if (stateLimit && states.size() >= stateLimit) { aborted = true; break; }
        if ((qi & 0xFFFFF) == 0 && qi) {
            std::printf("  enumerating: expanded %zu / known %zu\n", qi, states.size());
            std::fflush(stdout);
        }
        const State s = states[qi];

        bool hasWinMove = false;
        uint32_t childBuf[64];
        int childN = 0;

        uint64_t t = s.cur;
        while (t) {
            const int from = __builtin_ctzll(t);
            t &= t - 1;
            for (int d = 0; d < 4; d++) {
                State nx; int winner;
                if (!applyMove(s, from, d, nx, winner)) continue;

                // nx already has the side to move swapped: nx.cur holds the markers of
                // the opponent of the player who just moved, nx.opp those of the mover.
                if (__builtin_popcountll(nx.cur) < PMIN) { hasWinMove = true; continue; }
                if (__builtin_popcountll(nx.opp) < PMIN) continue;   // a move that loses q of one's own markers is never chosen

                nx = canonical(nx);

                bool isNew;
                const uint32_t nid = getId(nx, isNew);

                // count the distinct children, for the degree
                bool seen = false;
                for (int i = 0; i < childN; i++)
                    if (childBuf[i] == nid) { seen = true; break; }
                if (!seen && childN < 64) {
                    childBuf[childN++] = nid;
                    preds[nid].push_back((uint32_t)qi);
                }
            }
        }
        edgeCount += childN;
        degree[qi] = (uint8_t)childN;

        if (hasWinMove)      { result[qi] = 1; settled.push_back((uint32_t)qi); }
        else if (childN == 0) { result[qi] = 2; settled.push_back((uint32_t)qi); }
    }

    if (aborted) {
        std::printf("\nenumeration stopped after reaching the limit of %llu.\n",
                    (unsigned long long)stateLimit);
        std::printf("states: at least %zu\n", states.size());
        std::printf("result: ABORTED (undetermined; stopping early is not a draw)\n");
        return 2;
    }

    const auto t1 = std::chrono::steady_clock::now();

    // -----------------------------------------------------------------------
    // Stage 2: retrograde analysis
    // -----------------------------------------------------------------------
    for (size_t si = 0; si < settled.size(); si++) {
        const uint32_t v = settled[si];
        const uint8_t rv = result[v];
        for (uint32_t p : preds[v]) {
            if (result[p] != 0) continue;
            if (rv == 2) { result[p] = 1; settled.push_back(p); }
            else if (degree[p] > 0 && --degree[p] == 0) { result[p] = 2; settled.push_back(p); }
        }
    }

    const auto t2 = std::chrono::steady_clock::now();

    uint64_t cw = 0, cl = 0, cd = 0;
    for (size_t i = 0; i < result.size(); i++) {
        if (result[i] == 1) cw++; else if (result[i] == 2) cl++; else cd++;
    }

    const uint8_t r0 = result[initId];
    const char* verdict = (r0 == 1) ? "first player wins"
                        : (r0 == 2) ? "second player wins" : "draw";

    std::printf("========================================\n");
    std::printf(" OSTLE complete analysis  n = %d, m = %d, q = %d  (hash table, reachable only)\n", N, M, Q);
    std::printf("========================================\n");
    std::printf("board       : %d x %d, %d markers each, capture threshold %d\n", N, M, M, Q);
    std::printf("normalised  : side to move, reflections, lapsed forbidden moves\n");
    std::printf("----------------------------------------\n");
    std::printf("result      : %s\n", verdict);
    std::printf("----------------------------------------\n");
    std::printf("states      : %llu\n", (unsigned long long)states.size());
    std::printf("non-terminal transitions: %llu\n", (unsigned long long)edgeCount);
    std::printf("  mover wins: %llu\n", (unsigned long long)cw);
    std::printf("  draws     : %llu\n", (unsigned long long)cd);
    std::printf("  mover loses: %llu\n", (unsigned long long)cl);
    std::printf("enumeration : %.2f s\n", std::chrono::duration<double>(t1 - t0).count());
    std::printf("retrograde  : %.2f s\n", std::chrono::duration<double>(t2 - t1).count());
    std::printf("total       : %.2f s\n", std::chrono::duration<double>(t2 - t0).count());
    std::printf("========================================\n");
    return 0;
}
