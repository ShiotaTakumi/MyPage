// Numbers configurations and forbidden moves into consecutive integers, for any
// board size and marker count.
//
// ## Why it is general
//
// Before attacking 5x5 it is worth running the same code on small boards with
// known values (4x3, 4x4) and comparing. Fixing the board size would make that
// impossible.
//
// ## Assumption
//
// With capture threshold one the game ends the moment a marker is removed, so a
// non-terminal state always has p markers on each side. With the count fixed, the
// configuration can be ranked directly and no hash table is needed.
//
// ## Range of the forbidden move
//
// The square a forbidden move starts from always holds a marker of the player to
// move; the collapsing of lapsed restrictions normalises it that way. The range is
// therefore NONE + (p own markers x 4 directions) = 4p + 1 values, not
// squares x 4 + 1. Getting this wrong inflates the space several fold.
#pragma once
#include <cstdint>

namespace rankgen {

static int NR = 4, NC = 4, NCELL = 16, NPIECE = 4;
static uint64_t BINOM[64][16];
static uint64_t FIRST_CNT, SECOND_CNT, PLACE_CNT, BAN_CNT, TOTAL_CNT;

inline uint64_t binom(int n, int k) {
  if (k < 0 || n < 0 || k > n || n >= 64 || k >= 16) return 0;
  return BINOM[n][k];
}

inline void init(int nr, int nc, int npiece) {
  NR = nr; NC = nc; NCELL = nr * nc; NPIECE = npiece;
  for (int n = 0; n < 64; n++) {
    BINOM[n][0] = 1;
    for (int k = 1; k < 16; k++)
      BINOM[n][k] = (k > n) ? 0 : BINOM[n - 1][k - 1] + BINOM[n - 1][k];
  }
  FIRST_CNT = binom(NCELL, NPIECE);
  SECOND_CNT = binom(NCELL - NPIECE, NPIECE);
  PLACE_CNT = FIRST_CNT * SECOND_CNT;
  BAN_CNT = 4 * (uint64_t)NPIECE + 1;   // NONE + p own markers x 4 directions
  TOTAL_CNT = PLACE_CNT * BAN_CNT;
}

// Bitmask to its combinadic rank; mask has k bits set.
inline uint64_t maskToRank(uint64_t mask) {
  uint64_t r = 0;
  int i = 1;
  while (mask) {
    const int p = __builtin_ctzll(mask);
    mask &= mask - 1;
    r += binom(p, i);
    i++;
  }
  return r;
}

// Rank back to a mask with k bits set; n is the number of squares.
inline uint64_t rankToMask(uint64_t r, int n, int k) {
  uint64_t mask = 0;
  for (int i = k; i >= 1; i--) {
    int p = i - 1;
    while (p + 1 <= n - 1 && binom(p + 1, i) <= r) p++;
    mask |= 1ULL << p;
    r -= binom(p, i);
    n = p;
  }
  return mask;
}

// Maps into the coordinate system that skips the occupied squares.
inline uint64_t compress(uint64_t mask, uint64_t occupied) {
  uint64_t out = 0;
  int idx = 0;
  for (int i = 0; i < NCELL; i++) {
    if ((occupied >> i) & 1ULL) continue;
    if ((mask >> i) & 1ULL) out |= 1ULL << idx;
    idx++;
  }
  return out;
}

inline uint64_t expand(uint64_t cmask, uint64_t occupied) {
  uint64_t out = 0;
  int idx = 0;
  for (int i = 0; i < NCELL; i++) {
    if ((occupied >> i) & 1ULL) continue;
    if ((cmask >> idx) & 1ULL) out |= 1ULL << i;
    idx++;
  }
  return out;
}

inline uint64_t placementRank(uint64_t cur, uint64_t opp) {
  return maskToRank(cur) * SECOND_CNT + maskToRank(compress(opp, cur));
}

inline void placementUnrank(uint64_t r, uint64_t &cur, uint64_t &opp) {
  cur = rankToMask(r / SECOND_CNT, NCELL, NPIECE);
  opp = expand(rankToMask(r % SECOND_CNT, NCELL - NPIECE, NPIECE), cur);
}

// Maps the forbidden move (from, dir) to 0..4p. "from" must hold a marker of the
// player to move. 0 means NONE; 1..4p is (index of that marker x 4 + direction) + 1.
inline uint32_t banRank(uint64_t cur, uint8_t ban) {
  if (ban == 0xFF) return 0;
  const int from = ban >> 2, d = ban & 3;
  const uint64_t below = cur & ((1ULL << from) - 1);
  const int idx = __builtin_popcountll(below);
  return (uint32_t)(idx * 4 + d + 1);
}

// Inverse of banRank: recovers the actual (from, dir) from cur.
inline uint8_t banUnrank(uint64_t cur, uint32_t br) {
  if (br == 0) return 0xFF;
  br--;
  const int idx = br / 4, d = br % 4;
  uint64_t m = cur;
  for (int i = 0; i < idx; i++) m &= m - 1;
  const int from = __builtin_ctzll(m);
  return (uint8_t)((from << 2) | d);
}

inline uint64_t stateIndex(uint64_t cur, uint64_t opp, uint8_t ban) {
  return placementRank(cur, opp) * BAN_CNT + banRank(cur, ban);
}

inline void stateUnindex(uint64_t idx, uint64_t &cur, uint64_t &opp, uint8_t &ban) {
  placementUnrank(idx / BAN_CNT, cur, opp);
  ban = banUnrank(cur, (uint32_t)(idx % BAN_CNT));
}

}  // namespace rankgen
