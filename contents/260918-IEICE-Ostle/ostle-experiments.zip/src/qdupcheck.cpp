// Checks that, under capture threshold q, the fact that two different moves can
// reach the same configuration does not affect how the repetition rule is
// stored. Concretely: whenever two moves reach the same configuration, at least
// one of them must push a marker off the board.
//
// If two moves that leave the marker counts unchanged could reach the same
// configuration, then storing the forbidden move as a single reverse move would
// disagree with the rule in the paper, which forbids every move returning to the
// previous configuration.
#include "rankgenq.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
static int NR,NC,NCELL,NPIECE,Q,PMIN;
static const int DR[4]={-1,1,0,0}, DC[4]={0,0,-1,1};
static const uint8_t NO_MOVE=0xFF;
static inline bool inBoard(int r,int c){return r>=0&&r<NR&&c>=0&&c<NC;}
static inline bool applyMove(uint64_t cur,uint64_t opp,uint8_t ban,int from,int d,
                             uint64_t&ncur,uint64_t&nopp,uint8_t&nban,int&winner){
  if(!((cur>>from)&1ULL))return false;
  if(ban!=NO_MOVE&&ban==(uint8_t)((from<<2)|d))return false;
  const uint64_t occ=cur|opp; const int dr=DR[d],dc=DC[d];
  int line[64],len=1; line[0]=from;
  int rr=from/NC+dr,cc=from%NC+dc; int dest=inBoard(rr,cc)?rr*NC+cc:-1;
  while(dest>=0&&((occ>>dest)&1ULL)){line[len++]=dest;rr=dest/NC+dr;cc=dest%NC+dc;dest=inBoard(rr,cc)?rr*NC+cc:-1;}
  ncur=cur;nopp=opp;winner=0;int hole=dest;
  for(int i=len-1;i>=0;i--){const uint64_t bit=1ULL<<line[i];
    if(ncur&bit){ncur^=bit; if(hole<0)winner=2; else ncur|=1ULL<<hole;}
    else{nopp^=bit; if(hole<0)winner=1; else nopp|=1ULL<<hole;} hole=line[i];}
  nban=NO_MOVE;
  if(winner==0&&dest>=0&&((nopp>>dest)&1ULL)) nban=(uint8_t)((dest<<2)|(d^1));
  const uint64_t t=ncur;ncur=nopp;nopp=t;
  return true;
}
int main(int argc,char**argv){
  NR=atoi(argv[1]);NC=atoi(argv[2]);NPIECE=NC;Q=atoi(argv[3]);
  NCELL=NR*NC;PMIN=NPIECE-Q+1;
  rankgenq::init(NR,NC,NPIECE,Q);
  const uint64_t TOTAL=rankgenq::TOTAL_CNT;
  uint64_t dupTotal=0, dupNoDrop=0, dupBanDiffer=0;
  for(uint64_t i=0;i<TOTAL;i++){
    uint64_t cur,opp;uint8_t ban; rankgenq::stateUnindex(i,cur,opp,ban);
    struct C{uint64_t a,b;uint8_t nb;int drop;};
    C buf[80];int n=0;
    for(int from=0;from<NCELL;from++){
      if(!((cur>>from)&1ULL))continue;
      for(int d=0;d<4;d++){
        uint64_t nc,no;uint8_t nb;int w;
        if(!applyMove(cur,opp,ban,from,d,nc,no,nb,w))continue;
        if(__builtin_popcountll(nc)<PMIN||__builtin_popcountll(no)<PMIN)continue;
        const int drop=(w!=0);
        for(int j=0;j<n;j++) if(buf[j].a==nc&&buf[j].b==no){
          dupTotal++;
          if(!drop&&!buf[j].drop) dupNoDrop++;      // neither move removed a marker
          if(buf[j].nb!=nb) dupBanDiffer++;          // the stored forbidden move differs
        }
        if(n<80) buf[n++]=C{nc,no,nb,drop};
      }
    }
  }
  printf("%d x %d, capture threshold %d, %llu states\n",NR,NC,Q,(unsigned long long)TOTAL);
  printf("  move pairs reaching the same configuration : %llu\n",(unsigned long long)dupTotal);
  printf("  ... with no marker removed                : %llu  %s\n",(unsigned long long)dupNoDrop,
         dupNoDrop? "** the forbidden-move encoding is unsound":"<- zero means sound");
  printf("  ... with differing forbidden moves        : %llu  %s\n",(unsigned long long)dupBanDiffer,
         dupBanDiffer? "** needs checking":"<- zero means sound");
  return dupNoDrop||dupBanDiffer;
}
